/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/*******************************************************************************
* Function Name: main
********************************************************************************
*
* Summary:
*  main() performs following functions:
*  1: Starts the ADC and UART components.
*  2: Checks for ADC end of conversion.  Stores latest result in output
*     if conversion complete.
*  3: Checks for UART input.
*     On 'C' or 'c' received: transmits the last sample via the UART.
*     On 'S' or 's' received: continuously transmits samples as they are completed.
*     On 'X' or 'x' received: stops continuously transmitting samples.
*     On 'E' or 'e' received: transmits a dummy byte of data.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/

/* PSoC5 */
#include <device.h>
#include "stdio.h"
/* FreeRTOS */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"
/* API */
#include "com.h"
#include "utility.h"
#include "key.h"

/* Project Defines */
#define FALSE  0
#define TRUE   1

/* Resources for FreeRTOS */
#define TASK_STACK_LED   128
#define TASK_STACK_USBUART 1024
#define TASK_STACK_KEY   128
#define TASK_STACK_RADIO 512

#define TASK_PRIORITY_LED (tskIDLE_PRIORITY + 1)
#define TASK_PRIORITY_USBUART  (tskIDLE_PRIORITY + 2)
#define TASK_PRIORITY_KEY   (tskIDLE_PRIORITY + 2)
#define TASK_PRIORITY_RADIO (tskIDLE_PRIORITY + 1)

void Task_LED   (void *pvParameters);
void Task_USBUART (void *pvParameters);
void Task_KEY   (void *pvParameters);
void Task_RADIO (void *pvParameters);

xSemaphoreHandle xMutex_COM;    /* Mutex for COM Port */
xQueueHandle     xQueue_KEY[2]; /* Queue Data from Task_Key_Push() */
xQueueHandle     xQueue_IQ[2];  /* Queue Data from CY_ISR(Filter_Handler) */

/* USBUART */
/* Timeout for USB Connection (adjustment might be required) */
#define USBUART_TIMEOUT 2000000
volatile uint32 gUSBUART_Ready;

/* Function Prototypes */
void prvHardwareSetup(void);
void CORDIC(int32 x, int32 y, int32 *radius);
void Filter_Handler(void);

/*---------------------------------------------------------------------------*/
void prvHardwareSetup( void )
{
    /* Port layer functions that need to be copied into the vector table. */
    extern void xPortPendSVHandler( void );
    extern void xPortSysTickHandler( void );
    extern void vPortSVCHandler( void );
    extern cyisraddress CyRamVectors[];

	/* Install the OS Interrupt Handlers. */
	CyRamVectors[ 11 ] = ( cyisraddress ) vPortSVCHandler;
	CyRamVectors[ 14 ] = ( cyisraddress ) xPortPendSVHandler;
	CyRamVectors[ 15 ] = ( cyisraddress ) xPortSysTickHandler;
    
}
/*---------------------------------------------------------------------------*/
void vApplicationStackOverflowHook( TaskHandle_t pxTask, char *pcTaskName )
{
	/* The stack space has been execeeded for a task, considering allocating more. */
	taskDISABLE_INTERRUPTS();
	for( ;; );
}
/*---------------------------------------------------------------------------*/
void vApplicationMallocFailedHook( void )
{
	/* The heap space has been execeeded. */
	taskDISABLE_INTERRUPTS();
	for( ;; );
}
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Main */
/*---------------------------------------------------------------------------*/
int main()
{
    prvHardwareSetup();
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Initialize API */
    Init_Key();
    Init_COM();         /* USBUART */
    //COM_Wait_PC_Term(); /* Wait for setup PC Terminal */
    SPIM_Start();     /* SPI Master */

    /* Create Tasks */
    xMutex_COM = xSemaphoreCreateMutex();
    xQueue_KEY[0] = xQueueCreate(1, 1); // 1 x 1byte
    xQueue_KEY[1] = xQueueCreate(1, 1); // 1 x 1byte
    xQueue_IQ[0]  = xQueueCreate(8, 4); // 8 x 4bytes
    xQueue_IQ[1]  = xQueueCreate(8, 4); // 8 x 4bytes

    xTaskCreate(Task_LED, (signed portCHAR *)"LED", TASK_STACK_LED, NULL, TASK_PRIORITY_LED, NULL);
    xTaskCreate(Task_USBUART,(signed portCHAR *)"USBUART", TASK_STACK_USBUART, NULL, TASK_PRIORITY_USBUART, NULL);
    xTaskCreate(Task_KEY,   (signed portCHAR *)"KEY",   TASK_STACK_KEY,   NULL, TASK_PRIORITY_KEY,   NULL);
    xTaskCreate(Task_RADIO, (signed portCHAR *)"RADIO", TASK_STACK_RADIO, NULL, TASK_PRIORITY_RADIO, NULL);

    /* Start RTOS Kernel */
    vTaskStartScheduler();

    for(;;)
    {
        /* Place your application code here. */
    }
}

void Task_LED(void *pvParameters)
{
    /* Block time in (ms) */
    const portTickType OnDelay = 100 / portTICK_RATE_MS;
    const portTickType OffDelay = 900 / portTICK_RATE_MS;

    while(1)
    {
        LED_Write(1);
        vTaskDelay(OnDelay);
        
        LED_Write(0);
        vTaskDelay(OffDelay);
    }
}

#define BUFSIZE 16

void Task_USBUART(void *pvParameters)
{
    uint32 i;
    //int32  tcyc;
    int32  freq;    /* target Freq(kHz) 1kHz ~ 40MHz */
    int64  wdata;   /* set value of AD9850 using 125MHz X-tal */
    uint8  ch;
    uint8  str[BUFSIZE];
    uint8 *pstr;
    uint8  w[5] = {0xf8u, 0x8fu, 0x4cu, 0x07u, 0x00u};  /* LO freqency is quadruple of 891kHz */


    /* Block for 50ms */
    const portTickType xDelay = 50 / portTICK_RATE_MS;

    /* set DDS in serial mode */
    SPIM_WriteTxData(w[0]);
    SPIM_WriteTxData(w[1]);
    SPIM_WriteTxData(w[2]);
    SPIM_WriteTxData(w[3]);
    SPIM_WriteTxData(w[4]);
    vTaskDelay(xDelay);
    COM_printf("set DDS in serial mode.\r\n");
    
    /* Main Loop */
    for(;;)
    {
        /* Take xMutex_COM */
        xSemaphoreTake(xMutex_COM, portMAX_DELAY);

        /* Get Tcyc value */
        COM_printf("Enter freq(Hz)? ");
        for (i = 0; i < (BUFSIZE - 1); i++)
        {
            while(1)
            {
                uint8 len = USBUART_1_DataIsReady();
                if (len > 0) break;

                vTaskDelay(xDelay);    
            }
            USBUART_1_GetData(&ch, 1);
            USBUART_1_PutData(&ch, 1);
            if (ch == '\r') break;
            str[i] = ch;
        }
        str[i] = '\0';
        pstr = str;

        xatoi(&pstr, &freq);
        COM_printf("\r\n");
        COM_printf("Freq(Hz) = 0x%08x\r\n", freq);
        wdata = freq * 0x100000000u;
        wdata /= 125000000;
        wdata *= 4; /* LO freqency is quadruple of RX */

        for (i = 0; i < 4; i++)
        {
            w[i] = (uint8)((wdata >> i*8) & 0x000000FFu);
            COM_printf("w[%d] = 0x%02x\r\n", i, w[i]);  /* Debug */
        }
        /* if recieved expected string (number)? */
        if ((freq < 40000000) && (freq > 0))
        {
            /* writing data to the SPIM software buffer */
            SPIM_WriteTxData(w[0]);
            SPIM_WriteTxData(w[1]);
            SPIM_WriteTxData(w[2]);
            SPIM_WriteTxData(w[3]);
            SPIM_WriteTxData(w[4]);

            /* We need to know the moment when SPI communication is complete
            * to display received data. SPIS_SPI_DONE status should be polled. 
            */
            while(!(SPIM_ReadTxStatus() & SPIM_STS_SPI_DONE));
        }
        else
            COM_printf("invalid! set Freq(kHz) < 40MHz \r\n");
        
        xSemaphoreGive(xMutex_COM);

        vTaskDelay(xDelay);    

    }
        
}


/*---------------------------------------------------------------------------*/
/* SDR AM Radio */
/*---------------------------------------------------------------------------*/

/*****************************
 *  CORDIC Routine (16bits)  *
 *  (calculate amplitude)    *
 *****************************/
/* 1/1.6467602 * 65536 */
const int32 K = 39797;

void CORDIC(int32 x, int32 y, int32 *radius)
{
    int32 i;
    int32 u;

    for (i = 0; i < 16; i++)
    {
        if (y >= 0) {u = x + (y >> i); y = y - (x >> i);}
        else        {u = x - (y >> i); y = y + (x >> i);}
        x = u;
    }

    /* x = xqrt(x^2 + y^2) * K  (K=1.6467602) */
    *radius = x;
}

/****************************
 * Filter Interrupt Handler *
 ****************************/
CY_ISR(Filter_Handler)
{
    int32 filter_I;
    int32 filter_Q;

    if (Filter_1_IsInterruptChannelA())
    {
        filter_I = (int32) ((int16)Filter_1_Read16(Filter_1_CHANNEL_A));
        /* clear flags except INTR_HOLDB */
        Filter_1_SR_REG = Filter_1_ALL_INTR & (~Filter_1_CHANNEL_B_INTR);
        /* Send the Data to Queue */
        xQueueSendFromISR(xQueue_IQ[0], &filter_I, NULL);
    }
    if (Filter_1_IsInterruptChannelB())
    {
        filter_Q = (int32) ((int16)Filter_1_Read16(Filter_1_CHANNEL_B));
        /* clear flags except INTR_HOLDA */
        Filter_1_SR_REG = Filter_1_ALL_INTR & (~Filter_1_CHANNEL_A_INTR);
        /* Send the Data to Queue */
        xQueueSendFromISR(xQueue_IQ[1], &filter_Q, NULL);
    }
}

/*---------------------------------------------------------------------------*/
/* Define AGC Parameter */
#define AGC_TIM_MAX (25000 * 2) // 2sec
#define AGC_TIM_INI (AGC_TIM_MAX - 25000 / 4) // 1.75sec

void Task_RADIO(void *pvParameters)
{
    int32  filter_I;
    int32  filter_Q;
    uint8  dac;
    int32  radius;
    uint32 agc_tim;
    int32  agc_max;
    uint32 agc_mag;
    /* Variable declarations for DMA_1 and DMA_2 */
    uint8 DMA_1_Chan;
    uint8 DMA_1_TD[1];
    uint8 DMA_2_Chan;
    uint8 DMA_2_TD[1];

    /* DMA Configuration for DMA_1 */
    /* keep my spoke until the bytes are transfered */
    #define DMA_1_BYTES_PER_BURST   2
    #define DMA_1_REQUEST_PER_BURST 1
    #define DMA_1_SRC_BASE (CYDEV_PERIPH_BASE)
    #define DMA_1_DST_BASE (CYDEV_PERIPH_BASE)
    DMA_1_Chan = DMA_1_DmaInitialize(DMA_1_BYTES_PER_BURST, DMA_1_REQUEST_PER_BURST, HI16(DMA_1_SRC_BASE), HI16(DMA_1_DST_BASE));
    DMA_1_TD[0] = CyDmaTdAllocate();
    CyDmaTdSetConfiguration(DMA_1_TD[0], 2, DMA_INVALID_TD, DMA_1__TD_TERMOUT_EN | TD_INC_SRC_ADR | TD_INC_DST_ADR);
    CyDmaTdSetAddress(DMA_1_TD[0], LO16((uint32)ADC_SAR_1_SAR_WRK0_PTR), LO16((uint32)Filter_1_STAGEA_PTR));
    CyDmaChSetInitialTd(DMA_1_Chan, DMA_1_TD[0]);
    /* restore TD configuration after a transaction */
    CyDmaChEnable(DMA_1_Chan, 1);

    /* DMA Configuration for DMA_2 */
    /* keep my spoke until the bytes are transfered */
    #define DMA_2_BYTES_PER_BURST   2
    #define DMA_2_REQUEST_PER_BURST 1
    #define DMA_2_SRC_BASE (CYDEV_PERIPH_BASE)
    #define DMA_2_DST_BASE (CYDEV_PERIPH_BASE)
    DMA_2_Chan = DMA_2_DmaInitialize(DMA_2_BYTES_PER_BURST, DMA_2_REQUEST_PER_BURST, HI16(DMA_2_SRC_BASE), HI16(DMA_2_DST_BASE));
    DMA_2_TD[0] = CyDmaTdAllocate();
    CyDmaTdSetConfiguration(DMA_2_TD[0], 2, DMA_INVALID_TD, DMA_1__TD_TERMOUT_EN | TD_INC_SRC_ADR | TD_INC_DST_ADR);
    CyDmaTdSetAddress(DMA_2_TD[0], LO16((uint32)ADC_SAR_2_SAR_WRK0_PTR), LO16((uint32)Filter_1_STAGEB_PTR));
    CyDmaChSetInitialTd(DMA_2_Chan, DMA_2_TD[0]);
    /* restore TD configuration after a transaction */
    CyDmaChEnable(DMA_2_Chan, 1);

    /* Start Input PGA/Comp */
    PGA_1_Start();
    
    /* Start Input Comp */
    Comp_1_Start();

    /* Start Mixers */
    Mixer_1_Start();
    Mixer_2_Start();

    /* Start Audio DAC */
    VDAC8_1_Start();

    /* Start Filters */
    Filter_1_Start();
    Filter_1_INT_CTRL_REG = Filter_1_INT_CTRL_REG | 0x03;    /* to enable software polling */
    /*
     *  STAGEA, STAGEB : L/M written by DMAC (key byte lane is M, need 8bit alignment)
     *  HOLDA,  HOLDB  : M/H read by CPU     (key byte lane is H, no need alignment)
     */
    Filter_1_COHER_REG  = 0xa5;
    Filter_1_DALIGN_REG = 0x03;

    /* Enable Filter Interrupt */
    isr_filter_StartEx(Filter_Handler);    

    /* Start ADC (ensure the origin of events should be started last) */
    ADC_SAR_1_Start();
    ADC_SAR_2_Start();

    /* Initialize AGC Control */
    agc_tim = AGC_TIM_INI;
    agc_max = 0;
    agc_mag = 0;
    
    /* Main Loop */
    while(1)
    {   
        /*****************************
        *  Radio Data Processing
        ******************************/

        /* Get Bandpass Result from Queue and Generate Audio Output */
        if ((uxQueueMessagesWaiting(xQueue_IQ[0]) > 0) && (uxQueueMessagesWaiting(xQueue_IQ[1]) > 0))
        {
            xQueueReceive(xQueue_IQ[0], &filter_I, 0);        
            xQueueReceive(xQueue_IQ[1], &filter_Q, 0);
            
            if (filter_I < 0)
                filter_I = -filter_I;
            if (filter_Q < 0)
                filter_Q = -filter_Q;
            
            /* Calculation of Amplitude */
            CORDIC(filter_I, filter_Q, &radius);
            
            /* AGC */
            if (agc_tim < AGC_TIM_MAX)
            {
                agc_max = (radius > agc_max)? radius : agc_max;
                agc_tim++;
            }
            else
            {
                agc_mag = (256 << 16) / agc_max; 
                agc_max = 0;
                agc_tim = 0;
            }
            radius = (radius * agc_mag) >> 16;
            
            /* Audio Output */
            dac = (uint8) radius;
            VDAC8_1_SetValue(dac);
        }
    }
}

