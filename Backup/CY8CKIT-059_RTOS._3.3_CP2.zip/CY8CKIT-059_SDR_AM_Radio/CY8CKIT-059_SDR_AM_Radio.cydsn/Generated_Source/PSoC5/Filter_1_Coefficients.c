#include "Filter_1.h"
#include "Filter_1_PVT.h"


/*******************************************************************************
* ChannelA filter coefficients.
* Filter Type is: Biquad
*******************************************************************************/

/* Renamed array for backward compatibility.
*  Should not be used in new designs.
*/
#define ChannelABiquadCoefficients Filter_1_ChannelABiquadCoefficients

/* Number of Biquad sections are: 8 */

const uint8 CYCODE Filter_1_ChannelABiquadCoefficients[Filter_1_BIQUAD_A_SIZE] = 
{
 /* Coefficients of Section 0 */
 0x65u, 0x6Cu, 0x0Eu, 0x00u, /* Section(0)_A0, 0.225365877151489 */

 0x36u, 0x27u, 0xE3u, 0x00u, /* Section(0)_A1, -0.450731754302979 */

 0x65u, 0x6Cu, 0x0Eu, 0x00u, /* Section(0)_A2, 0.225365877151489 */

 0x69u, 0x37u, 0x7Eu, 0x00u, /* Section(0)_B1, -1.97213196754456 */

 0x37u, 0xBEu, 0xC1u, 0x00u, /* Section(0)_B2, 0.972765207290649 */

 /* Coefficients of Section 1 */
 0x08u, 0xBFu, 0x12u, 0x00u, /* Section(1)_A0, 0.292909622192383 */

 0x0Fu, 0x7Eu, 0x25u, 0x00u, /* Section(1)_A1, 0.585819005966187 */

 0x08u, 0xBFu, 0x12u, 0x00u, /* Section(1)_A2, 0.292909622192383 */

 0x8Eu, 0xF7u, 0x07u, 0x00u, /* Section(1)_B1, -0.124484539031982 */

 0x7Bu, 0x02u, 0xEDu, 0x00u, /* Section(1)_B2, 0.296723604202271 */

 /* Coefficients of Section 2 */
 0xA3u, 0xDAu, 0x25u, 0x00u, /* Section(2)_A0, 0.591469526290894 */

 0xBBu, 0x4Au, 0xB4u, 0x00u, /* Section(2)_A1, -1.18293881416321 */

 0xA3u, 0xDAu, 0x25u, 0x00u, /* Section(2)_A2, 0.591469526290894 */

 0x38u, 0x81u, 0x07u, 0x00u, /* Section(2)_B1, -0.11726188659668 */

 0x0Fu, 0xA5u, 0xF9u, 0x00u, /* Section(2)_B2, 0.0993006229400635 */

 /* Coefficients of Section 3 */
 0x9Au, 0x0Du, 0x20u, 0x00u, /* Section(3)_A0, 0.500830173492432 */

 0xCDu, 0xE4u, 0xBFu, 0x00u, /* Section(3)_A1, -1.00166010856628 */

 0x9Au, 0x0Du, 0x20u, 0x00u, /* Section(3)_A2, 0.500830173492432 */

 0xC5u, 0x6Fu, 0x07u, 0x00u, /* Section(3)_B1, -0.116196870803833 */

 0x98u, 0x21u, 0xFFu, 0x00u, /* Section(3)_B2, 0.0135746002197266 */

 /* Coefficients of Section 4 */
 0xD7u, 0x08u, 0x0Au, 0x00u, /* Section(4)_A0, 0.156789541244507 */

 0xAFu, 0x11u, 0x14u, 0x00u, /* Section(4)_A1, 0.313579320907593 */

 0xD7u, 0x08u, 0x0Au, 0x00u, /* Section(4)_A2, 0.156789541244507 */

 0xBFu, 0x8Fu, 0x09u, 0x00u, /* Section(4)_B1, -0.149398565292358 */

 0x45u, 0x5Eu, 0xD4u, 0x00u, /* Section(4)_B2, 0.681746244430542 */

 /* Coefficients of Section 5 */
 0x9Eu, 0xACu, 0x3Fu, 0x00u, /* Section(5)_A0, 0.994910717010498 */

 0xC3u, 0xA6u, 0x80u, 0x00u, /* Section(5)_A1, -1.98982167243958 */

 0x9Eu, 0xACu, 0x3Fu, 0x00u, /* Section(5)_A2, 0.994910717010498 */

 0xD3u, 0x59u, 0x7Fu, 0x00u, /* Section(5)_B1, -1.98985743522644 */

 0xDCu, 0x9Bu, 0xC0u, 0x00u, /* Section(5)_B2, 0.990487098693848 */

 /* Coefficients of Section 6 */
 0xDEu, 0x07u, 0x31u, 0x00u, /* Section(6)_A0, 0.766105175018311 */

 0xBBu, 0x0Fu, 0x62u, 0x00u, /* Section(6)_A1, 1.53221011161804 */

 0xDEu, 0x07u, 0x31u, 0x00u, /* Section(6)_A2, 0.766105175018311 */

 0x30u, 0x50u, 0x7Du, 0x00u, /* Section(6)_B1, -1.9580192565918 */

 0x48u, 0xA5u, 0xC2u, 0x00u, /* Section(6)_B2, 0.958662033081055 */

 /* Coefficients of Section 7 */
 0x53u, 0xACu, 0x27u, 0x00u, /* Section(7)_A0, 2.47957134246826 */

 0xA6u, 0x58u, 0x4Fu, 0x00u, /* Section(7)_A1, 4.95914268493652 */

 0x53u, 0xACu, 0x27u, 0x00u, /* Section(7)_A2, 2.47957134246826 */

 0xF1u, 0xCCu, 0x7Cu, 0x00u, /* Section(7)_B1, -1.95000863075256 */

 0x67u, 0x28u, 0xC3u, 0x00u, /* Section(7)_B2, 0.950659036636353 */
};


/*******************************************************************************
* ChannelB filter coefficients.
* Filter Type is: Biquad
*******************************************************************************/

/* Renamed array for backward compatibility.
*  Should not be used in new designs.
*/
#define ChannelBBiquadCoefficients Filter_1_ChannelBBiquadCoefficients

/* Number of Biquad sections are: 8 */

const uint8 CYCODE Filter_1_ChannelBBiquadCoefficients[Filter_1_BIQUAD_B_SIZE] = 
{
 /* Coefficients of Section 0 */
 0x65u, 0x6Cu, 0x0Eu, 0x00u, /* Section(0)_A0, 0.225365877151489 */

 0x36u, 0x27u, 0xE3u, 0x00u, /* Section(0)_A1, -0.450731754302979 */

 0x65u, 0x6Cu, 0x0Eu, 0x00u, /* Section(0)_A2, 0.225365877151489 */

 0x69u, 0x37u, 0x7Eu, 0x00u, /* Section(0)_B1, -1.97213196754456 */

 0x37u, 0xBEu, 0xC1u, 0x00u, /* Section(0)_B2, 0.972765207290649 */

 /* Coefficients of Section 1 */
 0x08u, 0xBFu, 0x12u, 0x00u, /* Section(1)_A0, 0.292909622192383 */

 0x0Fu, 0x7Eu, 0x25u, 0x00u, /* Section(1)_A1, 0.585819005966187 */

 0x08u, 0xBFu, 0x12u, 0x00u, /* Section(1)_A2, 0.292909622192383 */

 0x8Eu, 0xF7u, 0x07u, 0x00u, /* Section(1)_B1, -0.124484539031982 */

 0x7Bu, 0x02u, 0xEDu, 0x00u, /* Section(1)_B2, 0.296723604202271 */

 /* Coefficients of Section 2 */
 0xA3u, 0xDAu, 0x25u, 0x00u, /* Section(2)_A0, 0.591469526290894 */

 0xBBu, 0x4Au, 0xB4u, 0x00u, /* Section(2)_A1, -1.18293881416321 */

 0xA3u, 0xDAu, 0x25u, 0x00u, /* Section(2)_A2, 0.591469526290894 */

 0x38u, 0x81u, 0x07u, 0x00u, /* Section(2)_B1, -0.11726188659668 */

 0x0Fu, 0xA5u, 0xF9u, 0x00u, /* Section(2)_B2, 0.0993006229400635 */

 /* Coefficients of Section 3 */
 0x9Au, 0x0Du, 0x20u, 0x00u, /* Section(3)_A0, 0.500830173492432 */

 0xCDu, 0xE4u, 0xBFu, 0x00u, /* Section(3)_A1, -1.00166010856628 */

 0x9Au, 0x0Du, 0x20u, 0x00u, /* Section(3)_A2, 0.500830173492432 */

 0xC5u, 0x6Fu, 0x07u, 0x00u, /* Section(3)_B1, -0.116196870803833 */

 0x98u, 0x21u, 0xFFu, 0x00u, /* Section(3)_B2, 0.0135746002197266 */

 /* Coefficients of Section 4 */
 0xD7u, 0x08u, 0x0Au, 0x00u, /* Section(4)_A0, 0.156789541244507 */

 0xAFu, 0x11u, 0x14u, 0x00u, /* Section(4)_A1, 0.313579320907593 */

 0xD7u, 0x08u, 0x0Au, 0x00u, /* Section(4)_A2, 0.156789541244507 */

 0xBFu, 0x8Fu, 0x09u, 0x00u, /* Section(4)_B1, -0.149398565292358 */

 0x45u, 0x5Eu, 0xD4u, 0x00u, /* Section(4)_B2, 0.681746244430542 */

 /* Coefficients of Section 5 */
 0x9Eu, 0xACu, 0x3Fu, 0x00u, /* Section(5)_A0, 0.994910717010498 */

 0xC3u, 0xA6u, 0x80u, 0x00u, /* Section(5)_A1, -1.98982167243958 */

 0x9Eu, 0xACu, 0x3Fu, 0x00u, /* Section(5)_A2, 0.994910717010498 */

 0xD3u, 0x59u, 0x7Fu, 0x00u, /* Section(5)_B1, -1.98985743522644 */

 0xDCu, 0x9Bu, 0xC0u, 0x00u, /* Section(5)_B2, 0.990487098693848 */

 /* Coefficients of Section 6 */
 0xDEu, 0x07u, 0x31u, 0x00u, /* Section(6)_A0, 0.766105175018311 */

 0xBBu, 0x0Fu, 0x62u, 0x00u, /* Section(6)_A1, 1.53221011161804 */

 0xDEu, 0x07u, 0x31u, 0x00u, /* Section(6)_A2, 0.766105175018311 */

 0x30u, 0x50u, 0x7Du, 0x00u, /* Section(6)_B1, -1.9580192565918 */

 0x48u, 0xA5u, 0xC2u, 0x00u, /* Section(6)_B2, 0.958662033081055 */

 /* Coefficients of Section 7 */
 0x53u, 0xACu, 0x27u, 0x00u, /* Section(7)_A0, 2.47957134246826 */

 0xA6u, 0x58u, 0x4Fu, 0x00u, /* Section(7)_A1, 4.95914268493652 */

 0x53u, 0xACu, 0x27u, 0x00u, /* Section(7)_A2, 2.47957134246826 */

 0xF1u, 0xCCu, 0x7Cu, 0x00u, /* Section(7)_B1, -1.95000863075256 */

 0x67u, 0x28u, 0xC3u, 0x00u, /* Section(7)_B2, 0.950659036636353 */
};

