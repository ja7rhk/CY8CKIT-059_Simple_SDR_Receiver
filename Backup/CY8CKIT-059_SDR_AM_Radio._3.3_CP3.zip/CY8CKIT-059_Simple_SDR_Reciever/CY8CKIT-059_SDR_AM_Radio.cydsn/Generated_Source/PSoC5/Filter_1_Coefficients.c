#include "Filter_1.h"
#include "Filter_1_PVT.h"


/*******************************************************************************
* ChannelA filter coefficients.
* Filter Type is: Biquad
*******************************************************************************/

/* Renamed array for backward compatibility.
*  Should not be used in new designs.
*/
#define ChannelABiquadCoefficients Filter_1_ChannelABiquadCoefficients

/* Number of Biquad sections are: 8 */

const uint8 CYCODE Filter_1_ChannelABiquadCoefficients[Filter_1_BIQUAD_A_SIZE] = 
{
 /* Coefficients of Section 0 */
 0xEBu, 0x24u, 0x09u, 0x00u, /* Section(0)_A0, 0.142878293991089 */

 0x2Au, 0xB6u, 0xEDu, 0x00u, /* Section(0)_A1, -0.285756587982178 */

 0xEBu, 0x24u, 0x09u, 0x00u, /* Section(0)_A2, 0.142878293991089 */

 0xDAu, 0x71u, 0x3Du, 0x00u, /* Section(0)_B1, -0.960073947906494 */

 0x57u, 0xC5u, 0xE7u, 0x00u, /* Section(0)_B2, 0.378580331802368 */

 /* Coefficients of Section 1 */
 0x9Cu, 0xC8u, 0x28u, 0x00u, /* Section(1)_A0, 0.63724422454834 */

 0xC8u, 0x6Eu, 0xAEu, 0x00u, /* Section(1)_A1, -1.27448844909668 */

 0x9Cu, 0xC8u, 0x28u, 0x00u, /* Section(1)_A2, 0.63724422454834 */

 0x87u, 0x0Du, 0x4Fu, 0x00u, /* Section(1)_B1, -1.23520064353943 */

 0x51u, 0x60u, 0xDDu, 0x00u, /* Section(1)_B2, 0.540996313095093 */

 /* Coefficients of Section 2 */
 0xEAu, 0x9Au, 0x0Du, 0x00u, /* Section(2)_A0, 0.21258020401001 */

 0xD3u, 0x35u, 0x1Bu, 0x00u, /* Section(2)_A1, 0.42516016960144 */

 0xEAu, 0x9Au, 0x0Du, 0x00u, /* Section(2)_A2, 0.21258020401001 */

 0x8Cu, 0xBDu, 0x18u, 0x00u, /* Section(2)_B1, -0.386569023132324 */

 0xDAu, 0x5Cu, 0xE9u, 0x00u, /* Section(2)_B2, 0.353707790374756 */

 /* Coefficients of Section 3 */
 0x06u, 0x0Au, 0x28u, 0x00u, /* Section(3)_A0, 0.625611782073975 */

 0xF4u, 0xEBu, 0xAFu, 0x00u, /* Section(3)_A1, -1.25122356414795 */

 0x06u, 0x0Au, 0x28u, 0x00u, /* Section(3)_A2, 0.625611782073975 */

 0xBFu, 0xAFu, 0x5Cu, 0x00u, /* Section(3)_B1, -1.44822669029236 */

 0xACu, 0x5Bu, 0xD2u, 0x00u, /* Section(3)_B2, 0.713154792785645 */

 /* Coefficients of Section 4 */
 0x37u, 0x50u, 0x0Bu, 0x00u, /* Section(4)_A0, 0.176770925521851 */

 0x6Eu, 0xA0u, 0x16u, 0x00u, /* Section(4)_A1, 0.353541851043701 */

 0x37u, 0x50u, 0x0Bu, 0x00u, /* Section(4)_A2, 0.176770925521851 */

 0xCCu, 0x8Cu, 0x28u, 0x00u, /* Section(4)_B1, -0.633593559265137 */

 0xD8u, 0x48u, 0xEDu, 0x00u, /* Section(4)_B2, 0.292428970336914 */

 /* Coefficients of Section 5 */
 0xAAu, 0x07u, 0x10u, 0x00u, /* Section(5)_A0, 0.250467777252197 */

 0x53u, 0x0Fu, 0x20u, 0x00u, /* Section(5)_A1, 0.500935316085815 */

 0xAAu, 0x07u, 0x10u, 0x00u, /* Section(5)_A2, 0.250467777252197 */

 0x41u, 0x39u, 0x0Fu, 0x00u, /* Section(5)_B1, -0.237869501113892 */

 0xC6u, 0x42u, 0xDEu, 0x00u, /* Section(5)_B2, 0.527174472808838 */

 /* Coefficients of Section 6 */
 0xB4u, 0xF8u, 0x0Eu, 0x00u, /* Section(6)_A0, 0.233929634094238 */

 0x68u, 0xF1u, 0x1Du, 0x00u, /* Section(6)_A1, 0.467859268188477 */

 0xB4u, 0xF8u, 0x0Eu, 0x00u, /* Section(6)_A2, 0.233929634094238 */

 0x45u, 0x04u, 0x0Bu, 0x00u, /* Section(6)_B1, -0.172135591506958 */

 0x17u, 0x48u, 0xCCu, 0x00u, /* Section(6)_B2, 0.808099985122681 */

 /* Coefficients of Section 7 */
 0xBAu, 0xD8u, 0x31u, 0x00u, /* Section(7)_A0, 3.11541175842285 */

 0x8Cu, 0x4Eu, 0x9Cu, 0x00u, /* Section(7)_A1, -6.2308235168457 */

 0xBAu, 0xD8u, 0x31u, 0x00u, /* Section(7)_A2, 3.11541175842285 */

 0xD4u, 0xAEu, 0x68u, 0x00u, /* Section(7)_B1, -1.63567066192627 */

 0xFEu, 0x8Fu, 0xC6u, 0x00u, /* Section(7)_B2, 0.897461414337158 */
};


/*******************************************************************************
* ChannelB filter coefficients.
* Filter Type is: Biquad
*******************************************************************************/

/* Renamed array for backward compatibility.
*  Should not be used in new designs.
*/
#define ChannelBBiquadCoefficients Filter_1_ChannelBBiquadCoefficients

/* Number of Biquad sections are: 8 */

const uint8 CYCODE Filter_1_ChannelBBiquadCoefficients[Filter_1_BIQUAD_B_SIZE] = 
{
 /* Coefficients of Section 0 */
 0xEBu, 0x24u, 0x09u, 0x00u, /* Section(0)_A0, 0.142878293991089 */

 0x2Au, 0xB6u, 0xEDu, 0x00u, /* Section(0)_A1, -0.285756587982178 */

 0xEBu, 0x24u, 0x09u, 0x00u, /* Section(0)_A2, 0.142878293991089 */

 0xDAu, 0x71u, 0x3Du, 0x00u, /* Section(0)_B1, -0.960073947906494 */

 0x57u, 0xC5u, 0xE7u, 0x00u, /* Section(0)_B2, 0.378580331802368 */

 /* Coefficients of Section 1 */
 0x9Cu, 0xC8u, 0x28u, 0x00u, /* Section(1)_A0, 0.63724422454834 */

 0xC8u, 0x6Eu, 0xAEu, 0x00u, /* Section(1)_A1, -1.27448844909668 */

 0x9Cu, 0xC8u, 0x28u, 0x00u, /* Section(1)_A2, 0.63724422454834 */

 0x87u, 0x0Du, 0x4Fu, 0x00u, /* Section(1)_B1, -1.23520064353943 */

 0x51u, 0x60u, 0xDDu, 0x00u, /* Section(1)_B2, 0.540996313095093 */

 /* Coefficients of Section 2 */
 0xEAu, 0x9Au, 0x0Du, 0x00u, /* Section(2)_A0, 0.21258020401001 */

 0xD3u, 0x35u, 0x1Bu, 0x00u, /* Section(2)_A1, 0.42516016960144 */

 0xEAu, 0x9Au, 0x0Du, 0x00u, /* Section(2)_A2, 0.21258020401001 */

 0x8Cu, 0xBDu, 0x18u, 0x00u, /* Section(2)_B1, -0.386569023132324 */

 0xDAu, 0x5Cu, 0xE9u, 0x00u, /* Section(2)_B2, 0.353707790374756 */

 /* Coefficients of Section 3 */
 0x06u, 0x0Au, 0x28u, 0x00u, /* Section(3)_A0, 0.625611782073975 */

 0xF4u, 0xEBu, 0xAFu, 0x00u, /* Section(3)_A1, -1.25122356414795 */

 0x06u, 0x0Au, 0x28u, 0x00u, /* Section(3)_A2, 0.625611782073975 */

 0xBFu, 0xAFu, 0x5Cu, 0x00u, /* Section(3)_B1, -1.44822669029236 */

 0xACu, 0x5Bu, 0xD2u, 0x00u, /* Section(3)_B2, 0.713154792785645 */

 /* Coefficients of Section 4 */
 0x37u, 0x50u, 0x0Bu, 0x00u, /* Section(4)_A0, 0.176770925521851 */

 0x6Eu, 0xA0u, 0x16u, 0x00u, /* Section(4)_A1, 0.353541851043701 */

 0x37u, 0x50u, 0x0Bu, 0x00u, /* Section(4)_A2, 0.176770925521851 */

 0xCCu, 0x8Cu, 0x28u, 0x00u, /* Section(4)_B1, -0.633593559265137 */

 0xD8u, 0x48u, 0xEDu, 0x00u, /* Section(4)_B2, 0.292428970336914 */

 /* Coefficients of Section 5 */
 0xAAu, 0x07u, 0x10u, 0x00u, /* Section(5)_A0, 0.250467777252197 */

 0x53u, 0x0Fu, 0x20u, 0x00u, /* Section(5)_A1, 0.500935316085815 */

 0xAAu, 0x07u, 0x10u, 0x00u, /* Section(5)_A2, 0.250467777252197 */

 0x41u, 0x39u, 0x0Fu, 0x00u, /* Section(5)_B1, -0.237869501113892 */

 0xC6u, 0x42u, 0xDEu, 0x00u, /* Section(5)_B2, 0.527174472808838 */

 /* Coefficients of Section 6 */
 0xB4u, 0xF8u, 0x0Eu, 0x00u, /* Section(6)_A0, 0.233929634094238 */

 0x68u, 0xF1u, 0x1Du, 0x00u, /* Section(6)_A1, 0.467859268188477 */

 0xB4u, 0xF8u, 0x0Eu, 0x00u, /* Section(6)_A2, 0.233929634094238 */

 0x45u, 0x04u, 0x0Bu, 0x00u, /* Section(6)_B1, -0.172135591506958 */

 0x17u, 0x48u, 0xCCu, 0x00u, /* Section(6)_B2, 0.808099985122681 */

 /* Coefficients of Section 7 */
 0xBAu, 0xD8u, 0x31u, 0x00u, /* Section(7)_A0, 3.11541175842285 */

 0x8Cu, 0x4Eu, 0x9Cu, 0x00u, /* Section(7)_A1, -6.2308235168457 */

 0xBAu, 0xD8u, 0x31u, 0x00u, /* Section(7)_A2, 3.11541175842285 */

 0xD4u, 0xAEu, 0x68u, 0x00u, /* Section(7)_B1, -1.63567066192627 */

 0xFEu, 0x8Fu, 0xC6u, 0x00u, /* Section(7)_B2, 0.897461414337158 */
};

