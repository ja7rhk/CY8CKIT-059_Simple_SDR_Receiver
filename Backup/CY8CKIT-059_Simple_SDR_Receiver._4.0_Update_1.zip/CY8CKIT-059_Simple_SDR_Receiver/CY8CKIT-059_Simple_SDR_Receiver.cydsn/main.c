//----------------------------------------------------------------------------
//
//	SIMPLE SDR RECEIVER PSoC3 FIRMWARE for Hardware Rev -
//
//	Copyright 2011 Simple Circuits Inc.
//
//	06/03/2011	Original release.
//
//
//
//	ADC sample rate is 32068 sps total, or 16034 sps per channel
//
//----------------------------------------------------------------------------
//
// PSoC3 => PSoC5LP
//
//  Sumio Koseki (JA7RHK)
//	05/28/2017
//
//----------------------------------------------------------------------------
#include <string.h>
#include <stdio.h>
#include <math.h>
#include "main.h"
// FreeRTOS
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"
// API
#include "rot.h"
#include "key.h"
#include "I2C_CLCD.h"
#include "USBUART_API.h"

//----------------------------------------------------------------------------
//
//	Constants
//
//----------------------------------------------------------------------------
// PSoC3 => PSoC5LP
#define	FREQ_START			"00891000"			// in ASCII BCD chars
#define	FREQ_PLL_TEST		"00457000"			// pll lock test frequency
#define	FREQ_LOW			100000              // 100kHz
#define	FREQ_HIGH		    8000000             // 8MHz
#define USBUART_TIMEOUT 2000000 // Timeout for USB Connection (adjustment might be required)
//#define DEBUG_USBUART       // Debug Mode

const uint8 HEX2ASCII [] = {"0123456789ABCDEF"};
extern const uint8 CYCODE Filter_data_b_2500[];	// FIR coefficients
extern const uint8 CYCODE Filter_data_b_2000[];	// FIR coefficients
extern const uint8 CYCODE Filter_data_b_1500[];	// FIR coefficients
extern const uint8 CYCODE Filter_data_b_cw[];	// FIR coefficients
extern const uint8 CYCODE Filter_data_b_am[];	// FIR coefficients
extern const int32 CYCODE Hilbert [];			// Hilbert tranformer coefficients

// PSoC3 => PSoC5LP
#define PARAM_MAX  8
reg8 *pFREQ_ERROR = (reg8*)(CYDEV_EE_BASE + 16 * FQ_ROW);
reg8 *pSERIAL_NUM = (reg8*)(CYDEV_EE_BASE + 16 * SN_ROW);
uint8 FREQ_ERROR[PARAM_MAX];    // freq offset is 1st row of eeprom
uint8 SERIAL_NUM[PARAM_MAX];    // serial number is 2nd row of eeprom

// PSoC3 => PSoC5LP
volatile uint32 gUSBUART_Ready;

//----------------------------------------------------------------------------
//
// Channel Selecton
//
//----------------------------------------------------------------------------
#define STATION_MAX 7

typedef struct
{
    char    Name[5];
    uint32  Freq;
    uint32  Offset;
    uint32  Step;
    uint8   Mode;
    uint8   Filter;
} Station;

Station station[STATION_MAX] = 
{
    {"NHK1 ", 891000, 0, 1, MODE_USB, FILTER_AM },
    {"NHK2 ", 1089000, 0, 1, MODE_USB, FILTER_AM },
    {"TBC  ", 1260000, 0, 1, MODE_USB, FILTER_AM },
    {"NHK1 ", 891000, 4000, 1000, MODE_AM, FILTER_AM },       // AM IF = 4 kHz
    {"NHK2 ", 1089000, 4000, 1000, MODE_AM, FILTER_AM },
    {"TBC  ", 1260000, 4000, 1000, MODE_AM, FILTER_AM },
    {"BCON ", 457000, 800, 10, MODE_CW, FILTER_FL4 },        // CW BFO = 800Hz
};

//
//----------------------------------------------------------------------------
//
//	Global variables
//
//----------------------------------------------------------------------------
uint8	Freq [8];					// receive frequency in ASCII BCD
uint8	LastFreq [8];				// copy of last tuned rx frequency
int32	Frequency;					// receive frequency in binary
int32	FrequencyError;				// frequency error at 10 MHz

uint8	ComRxCmd [32];				// remote command rx buffer
uint8	ComRxPtr;					// pointer into com rx buffer
//uint8	UsbTxBuffer [64];			// USB transmit buffer
uint8	UsbTxBuffer [80];			// USB transmit buffer
uint8	UsbRxBuffer [256];			// USB receive buffer

uint8	AdcTick;					// ADC interrupt flag every 6.521 msec
int16	IDCOffset, QDCOffset;		// DC offset values for ADC input
int16	AdcPeak, AdcPeakAve;		// ADC input peak value, and its average
uint8	AgcDisable;					// Agc disable flag
uint8	AgcGain;					// AGC for ADC input
uint8	AgcTimer;					// AGC processing timer
uint8	AgcIntegrator;				// AGC integrator
uint32	AgcIndicator;				// AGC signal strength indicatior
uint8	AgcTimeConstant;			// AGC time constant

uint8	LedTimer;					// LED on timer
uint8	DisplayIndex;				// index for status display

uint8	Filter;						// audio filter bandwidth selection
uint8	Mode;						// operating mode
uint8	UpperSideBand;				// upper side band mode selection
uint8	AttenuatorOn;				// rx attenuator on/off flag
uint8	Squelch;					// squelch level, 0 - 250.
uint8	Debug;						// debug mode flag, turns off boundary checks
uint8   Ch;                         // channel number (2017.5.31)koseki

// ADC Interrupt Handler
uint8	AdcState;					// IQ channel processing flag
int16	IDelay [64];
uint8	IDelayPtr;

//----------------------------------------------------------------------------
//
//	Resources for FreeRTOS
//
//----------------------------------------------------------------------------
#define TASK_STACK_LED   128
#define TASK_STACK_KEY   128
#define TASK_STACK_ROT   128
#define TASK_STACK_CLCD  512
#define TASK_STACK_USBUART  512
#define TASK_STACK_RADIO    512

#define TASK_PRIORITY_LED   (tskIDLE_PRIORITY + 3)
#define TASK_PRIORITY_KEY   (tskIDLE_PRIORITY + 3)
#define TASK_PRIORITY_ROT   (tskIDLE_PRIORITY + 3)
#define TASK_PRIORITY_CLCD  (tskIDLE_PRIORITY + 2)
#define TASK_PRIORITY_USBUART   (tskIDLE_PRIORITY + 2)
#define TASK_PRIORITY_RADIO     (tskIDLE_PRIORITY + 2)

void Task_LED   (void *pvParameters);
void Task_KEY   (void *pvParameters);   // .\Utility\key.c
void Task_ROT   (void *pvParameters);   // .\Utility\rot.c
void Task_CLCD  (void *pvParameters);
void Task_USBUART   (void *pvParameters);
void Task_RADIO     (void *pvParameters);

xSemaphoreHandle xMutex_DDS;    // Mutex for Parameter Control

xQueueHandle xQueue_KEY[2];     // Task_KEY -> Task_CCD
xQueueHandle xQueue_ROT;        // Task_ROT -> Task_CCD
xQueueHandle xQueue_FREQ;       // Task_USB -> Task_CCD

// Function Prototypes
void prvHardwareSetup(void);
void CORDIC(int32 x, int32 y, int32 *radius);

//----------------------------------------------------------------------------
//
//	MAIN
//
//----------------------------------------------------------------------------
//void main()
int main()
{
    prvHardwareSetup();

	Initialize ();

    /* Create Tasks */
    xMutex_DDS = xSemaphoreCreateMutex();
    xQueue_ROT    = xQueueCreate(8, 1);     // 8 x 1byte
    xQueue_KEY[0] = xQueueCreate(1, 1);     // 1 x 1byte
    xQueue_KEY[1] = xQueueCreate(1, 1);     // 1 x 1byte
    xQueue_FREQ  = xQueueCreate(1, 1);      // 1 x 1bytes

    CyDelay(1000u);

    xTaskCreate(Task_LED, "LED", TASK_STACK_LED, NULL, TASK_PRIORITY_LED, NULL);
    xTaskCreate(Task_ROT, "ROT", TASK_STACK_ROT, NULL, TASK_PRIORITY_ROT, NULL);
    xTaskCreate(Task_KEY, "KEY", TASK_STACK_KEY, NULL, TASK_PRIORITY_KEY, NULL);
    xTaskCreate(Task_CLCD, "CLCD", TASK_STACK_CLCD, NULL, TASK_PRIORITY_CLCD, NULL);
    xTaskCreate(Task_USBUART, "USBUART", TASK_STACK_USBUART, NULL, TASK_PRIORITY_USBUART, NULL);
    xTaskCreate(Task_RADIO, "RADIO", TASK_STACK_RADIO, NULL, TASK_PRIORITY_RADIO, NULL);

    /* Start RTOS Kernel */
    vTaskStartScheduler();
    
    for(;;)
    {
        /* Place your application code here. */
    }
}

//----------------------------------------------------------------------------
//
//	Initialize and configure hardware, initialize variables
//
//----------------------------------------------------------------------------
void Initialize (void)
{
    uint32 i;
    char str[20];
    uint8  w[5] = {0u, 0u, 0u, 0u, 0u};
    
	CyDelay (100);					// delay in msec
    
    // PSoC3 => DDS, I2C_CLCD
    SPIM_Start();
    I2C_1_Start();
    I2C_CLCD_Start();

    // Start Input Comp
    Comp_1_Start();
	VDAC_1_Start ();					// start DAC output

	//CyPins_SetPin (TP2_OUT_0);
	//CyPins_SetPin (REDLED_0);		// red led off
    
	Filter_Start ();				// start FIR filter
	VDAC_Start ();					// start DAC output
	
	ADC_Start ();					// power up and start 16 bit ADC
	ADC_IRQ_Enable ();
    isr_adc_StartEx(ADC_ISR_Handler);
	ADC_StartConvert ();			// start conversions
    
	CyDelay (100);					// delay in msec

    I2C_CLCD_ClearLine(0u);
    I2C_CLCD_ClearLine(1u);
	
	// initialize vars
	Filter = FILTER_FL2;			// selects 2000 Hz LPF
	SetMode (MODE_USB);
	IDCOffset = QDCOffset = 0x500;	// preset offset for better settling time
    AgcTimeConstant = 4;            // Default AGC Time constant

    // set DDS to default frequency
    SPIM_WriteTxData(w[0]);
    SPIM_WriteTxData(w[1]);
    SPIM_WriteTxData(w[2]);
    SPIM_WriteTxData(w[3]);
    SPIM_WriteTxData(w[4]);

	EEPROM_Start ();				// power up eeprom

	CyDelay (100);					// delay in msec
    
    // PSoC3 => PSoC5LP
    for (i = 0; i < PARAM_MAX; i++)
        SERIAL_NUM[i] = pSERIAL_NUM[i];

    if (SERIAL_NUM [0] != '0')
	{
		CySetTemp ();				// acquire die temperature before writing eeprom
		EEPROM_Write ((uint8*)"00000000", SN_ROW);	// write and wait for completion
        // AD9850_DDS
		EEPROM_Write ((uint8*)"5000000", FQ_ROW);	// write and wait for completion
	}

	FrequencyError = 0;
	//memcpy (Freq, FREQ_PLL_TEST, 8);// initialize the clock generator output frequency
	//SetFrequency ();

	CyDelay (200);					// delay in msec
	CYGlobalIntEnable;
	
    // PSoC3 => PSoC5LP
    for (i = 0; i < PARAM_MAX; i++)
        FREQ_ERROR[i] = pFREQ_ERROR[i];
        
    // AD9850 DDS
	FrequencyError = 5000000 - BinaryFrequency (FREQ_ERROR);	// 5MHz
    if ((FrequencyError > 1000) || (FrequencyError < -1000))	// bounds checking
		FrequencyError = 0;
	memcpy (Freq, FREQ_START, 8);			// initialize the clock generator output frequency
	SetFrequency ();

    // CLCD display station
    sprintf(str, "%5s", station[Ch].Name);
    I2C_CLCD_Position(0u, 0u);
    I2C_CLCD_PrintString(str);
}

//----------------------------------------------------------------------------
void prvHardwareSetup( void )
{
    /* Port layer functions that need to be copied into the vector table. */
    extern void xPortPendSVHandler( void );
    extern void xPortSysTickHandler( void );
    extern void vPortSVCHandler( void );
    extern cyisraddress CyRamVectors[];

	/* Install the OS Interrupt Handlers. */
	CyRamVectors[ 11 ] = ( cyisraddress ) vPortSVCHandler;
	CyRamVectors[ 14 ] = ( cyisraddress ) xPortPendSVHandler;
	CyRamVectors[ 15 ] = ( cyisraddress ) xPortSysTickHandler;
    
}
//----------------------------------------------------------------------------

void vApplicationStackOverflowHook( TaskHandle_t pxTask, char *pcTaskName )
{
	/* The stack space has been execeeded for a task, considering allocating more. */
	taskDISABLE_INTERRUPTS();
	for( ;; );
}
//----------------------------------------------------------------------------

void vApplicationMallocFailedHook( void )
{
	/* The heap space has been execeeded. */
	taskDISABLE_INTERRUPTS();
	for( ;; );
}
//----------------------------------------------------------------------------


//============================================================================
//
//	Task_LED
//
//============================================================================
void Task_LED(void *pvParameters)
{
    /* Block time in (ms) */
    const portTickType OnDelay = 100 / portTICK_RATE_MS;
    const portTickType OffDelay = 900 / portTICK_RATE_MS;

    while(1)
    {
        BLUELED_Write(1u);
        vTaskDelay(OnDelay);
        
        BLUELED_Write(0u);
        vTaskDelay(OffDelay);
    }
}


//============================================================================
//
//	Task_CLCD
//
//============================================================================
// CLCD Display
//  0123456789012345
// ------------------
// |NHK1 _891000[Hz]|
// |USB  FW=4.0k S46|
//
#define cNAME  0u
#define cFREQ  5u
#define cMD  0u
#define cFW  5u
#define cAGC 13u

void Task_CLCD(void *pvParameters)
{
    int8   click;
    uint8  qmsg;
    uint32 step_freq;
    uint8 cnt = 0x20;
    char str[20];
    const portTickType xDelay = 100 / portTICK_RATE_MS;

    AgcIndicator = 0;
    I2C_CLCD_Position(1u, cAGC);
    I2C_CLCD_PrintString("S__");

    // Default channel set
    Ch = 0;
    ChannelSet(Ch);
    
    // Main Loop
 	while (1)
	{
        xSemaphoreTake(xMutex_DDS, portMAX_DELAY);
        
        // Get click count of ROT
        if (uxQueueMessagesWaiting(xQueue_ROT) > 0)
        {
            xQueueReceive(xQueue_ROT, &click, 0);
            // target frequency
            step_freq = station[Ch].Step;
            sprintf((char*)Freq, "%08ld", Frequency + (click * step_freq));
            SetFrequency();
        }
        if (xQueueReceive(xQueue_KEY[0], &qmsg, 0))
        {
            Ch++;
            if (Ch >= STATION_MAX)
                Ch = 0;
            ChannelSet(Ch);
        }
        if (xQueueReceive(xQueue_KEY[1], &qmsg, 0))
        {
            if (Ch == 0)
                Ch = STATION_MAX - 1;
            else
                Ch--;
            ChannelSet(Ch);
        }

        cnt--;
        if ((cnt & 0x07) == 0)
            AgcIndicator += (64 - AgcGain);
        if (cnt == 0)
        {
            sprintf(str, "S%02d", (uint8)(AgcIndicator >> 2));
            I2C_CLCD_Position(1u, cAGC);
            I2C_CLCD_PrintString(str);
            cnt = 0x20;
            AgcIndicator = 0;
        }
        xSemaphoreGive(xMutex_DDS);

        vTaskDelay(xDelay);
    }
}

//
//	Update the selected channel
//
void ChannelSet(uint8 ch)
{
    char str[20];

    // setup the new station
    sprintf((char*)Freq, "%08ld", station[Ch].Freq);
    SetFrequency();
    Mode = station[ch].Mode;
	SetMode(Mode);
    Filter = station[ch].Filter;
    LoadFilter(Filter);
    
    sprintf(str, "%s", station[ch].Name);
    I2C_CLCD_Position(0u, cNAME);
    I2C_CLCD_PrintString(str);
    
    AgcIndicator = 0;   // reset signal strength indicatior
}

//
//	Load DFB filter data into coefficient RAM
//
void LoadFilter (uint8 fltr)
{
	uint8 i, j;
	int32 x;
	uint8 xbuf [256];

	// Put DFB RAM on the bus
    Filter_RAM_DIR_REG = Filter_RAM_DIR_BUS;

	if (fltr == FILTER_FL1)
        cymemcpy(Filter_DB_RAM, Filter_data_b_2500, Filter_DB_RAM_SIZE);
	else if (fltr == FILTER_FL2)
        cymemcpy(Filter_DB_RAM, Filter_data_b_2000, Filter_DB_RAM_SIZE);
	else if (fltr == FILTER_FL3)
        cymemcpy(Filter_DB_RAM, Filter_data_b_1500, Filter_DB_RAM_SIZE);
	else if (fltr == FILTER_FL4)
        cymemcpy(Filter_DB_RAM, Filter_data_b_cw, Filter_DB_RAM_SIZE);
	else if (fltr == FILTER_AM)
        cymemcpy(Filter_DB_RAM, Filter_data_b_am, Filter_DB_RAM_SIZE);
	else if (fltr == FILTER_RST)
        cymemcpy(Filter_DB_RAM, Filter_data_b, Filter_DB_RAM_SIZE);

    // copy Hilbert filter coefficients into filter channel B ram
	j = 0;
	for (i = 0; i < 64; i++) 
	{
		x = Hilbert [i];
		xbuf [j++] = x & 0xFF;
		xbuf [j++] = (x >> 8) & 0xFF;
		xbuf [j++] = (x >> 16) & 0xFF;
		xbuf [j++] = 0;
	}
	cymemcpy(Filter_DB_RAM + 256, xbuf, Filter_DB_RAM_SIZE / 2);
		
	// Take DFB RAM off the bus
	Filter_RAM_DIR_REG = Filter_RAM_DIR_DFB;
    
    // CLCD Display "filter band width"
    char str[20];
    switch(fltr)
    {
        case FILTER_FL1:
            sprintf(str,"FW=2.5k");
            break;
        case FILTER_FL2:
            sprintf(str,"FW=2.0k");
            break;
        case FILTER_FL3:
            sprintf(str,"FW=1.5k");
            break;
        case FILTER_FL4:
            sprintf(str,"FW=0.4k");
            break;
        case FILTER_AM:
            sprintf(str,"FW=4.0k");
            break;
        default:
            break;
    }
    I2C_CLCD_Position(1u, cFW);
    I2C_CLCD_PrintString(str);

}

//
//	Frequency synthesizer set frequency
//	Freq (MHz)  = (24/9) * (N + Frac/16384) / (4 * IQDividerRatio)
//				= 2 * (N + Frac/16384) / (3 * IQDividerRatio)
//
void SetFrequency (void)
{
	//uint8 pllN, iqDivider, fracLo, fracHi;
	uint32 frq;
    // PSoC3 => DSS/CLCD control
	uint32 newfreq;
    uint64 wdata;       // DDS set value for AD9850 using 125MHz X-tal */
    uint8 w[5] = {0xf8u, 0x08u, 0x4cu, 0x07u, 0x00u};
    uint8 i;
    char str[20];
	
	if (!memcmp (Freq, LastFreq, 8))	// check if already tuned to that frequency
		return;							// ignore set frequency command and return

	frq = BinaryFrequency (Freq);		// compute binary value from string

	if ((!Debug) && ((frq < FREQ_LOW) || (frq > FREQ_HIGH))) // ignore frequencies outside tuning range
	{
		memcpy (Freq, LastFreq, 8);	// restore last frequency allowed
		return;
	}
	memcpy (LastFreq, Freq, 8);
	Frequency = frq;				// save new receive frequency (binary form)
    
    // PSoC3 PLL => DSS/CLCD control

    // offset by frequency error (factory adjusted)
	frq += (( (int32) frq / 100) * FrequencyError) / 50000;
    // (2017.5.31)koseki
    frq += station[Ch].Offset;
    // DDS frequency is quadruple of Rx frequency 
    newfreq = frq * 4;
    wdata = newfreq * 0x100000000u;
    wdata /= 125000000;

    for (i = 0; i < 4; i++)
        w[i] = (uint8)((wdata >> i * 8) & 0x000000FFu);
    if ((frq < 40000000) && (frq > 0))
    {
        // mute the input signal during frequency changes
    	AgcGain = 0;
        // writing data to the SPIM software buffer
        SPIM_WriteTxData(w[0]);
        SPIM_WriteTxData(w[1]);
        SPIM_WriteTxData(w[2]);
        SPIM_WriteTxData(w[3]);
        SPIM_WriteTxData(w[4]);
        // We need to know the moment when SPI communication is complete
        // to display received data. SPIS_SPI_DONE status should be polled. 
        while(!(SPIM_ReadTxStatus() & SPIM_STS_SPI_DONE));
        sprintf(str, "%7ld[Hz]", Frequency);
    }
    else
        sprintf(str, "Error  [Hz]");
        
    I2C_CLCD_Position(0u, cFREQ);
    I2C_CLCD_PrintString(str);

    CyDelay (1);
}

//
//	Set operating mode
//
void SetMode (uint8 md)
{
	Mode = md;					// save operating mode
    
	UpperSideBand = ((Mode == MODE_USB) || (Mode == MODE_CW) || (Mode == MODE_RTTY));
		
	if ((Mode == MODE_CW) || (Mode == MODE_CWREV))
		Filter = FILTER_FL4;
	//else if ((Mode <= MODE_USB) && (Filter == FILTER_FL4))
	else if ((Mode == MODE_USB) || (Mode == MODE_LSB))
		Filter = FILTER_FL2;
    // (2017.6.1)koseki
	//LoadFilter (Filter);
    
    // CLCD Display "mode"
    char str[20];
    switch(Mode)
    {
        case MODE_LSB:
            sprintf(str,"LSB  ");
            break;
        case MODE_USB:
            sprintf(str,"USB  ");
            break;
        case MODE_CW:
            sprintf(str,"CW   ");
            break;
        case MODE_AM:               // (2017.6.24)koseki
            sprintf(str,"AM   ");
            break;
        default:
            sprintf(str,"***  ");
            break;
    }
    I2C_CLCD_Position(1u, cMD);
    I2C_CLCD_PrintString(str);
}

//
//	Compute binary frequency value from ASCII character string
//
uint32 BinaryFrequency (uint8 *ptr)
{
	uint8 i;
	uint32 frq, dec;
	
	frq = 0;
	dec = 10000000;					// 10's of MHz
	for (i = 0; i < 8; i++)
	{
		frq += (*ptr++ - '0') * dec;
		dec /= 10;
	}
	return (frq);
}

			
//============================================================================
//
//	Task_USBUART
//
//============================================================================
void Task_USBUART(void *pvParameters)
{
    uint32 i;
    uint8 Flag = 1;
    uint8 state;
    
    USBUART_Start(0, USBUART_DWR_VDDD_OPERATION);
    for (i = 0; i < USBUART_TIMEOUT; i++)
    {
        gUSBUART_Ready = USBUART_bGetConfiguration();
        if (gUSBUART_Ready) break;
    }
    // Initiaize UABUART
    if (gUSBUART_Ready)
        USBUART_CDC_Init();
    else
        USBUART_Stop();

    while(Flag)
    {  
    	state = USBUART_IsLineChanged();
    	if (state & USBUART_LINE_CODING_CHANGED)
    	{
            USBUART_Write((uint8*)"Program starts\r\n");

            Flag = 0;
            CyDelay(100);
            USBUART_Write((uint8*)"***********************************************************\r\n");
            USBUART_Write((uint8*)"*                                                         *\r\n");
            USBUART_Write((uint8*)"*                 Simple SDR Reciever                     *\r\n");
            USBUART_Write((uint8*)"*               for CY8KIT-059 (PSoC-5LP)                 *\r\n");
            USBUART_Write((uint8*)"*                                                         *\r\n");
            USBUART_Write((uint8*)"*                     (ver.0.0.1)                         *\r\n");
            USBUART_Write((uint8*)"*                                                         *\r\n");
            USBUART_Write((uint8*)"***********************************************************\r\n");
            USBUART_Write((uint8*)"""Ham Radio Deluxe"" equivalent commands are enabled.\r\n");
            USBUART_Write((uint8*)"\r\n");
        }
    }
    // Main Loop
 	while (1)
	{
		//AdjustAgc ();				// AGC adjustment		

		ReadUSB ();					// read the USB port for command data
    }
}

// maximum command length (FA00000891000;) while ComRxCmd size is 32B
#define MAX_CMD_LENGTH  16
//
//	Read USB port for COM data
//
void ReadUSB (void)
{
	uint8 bCount, rx, i;

    if(USBUART_DataIsReady() > 0)       // check the USB Rx data ready
	{
		USBUART_ReadAll(UsbRxBuffer);	// read usb rx data
        for (i = 0; i < MAX_CMD_LENGTH; i++)
        {
            if(UsbRxBuffer[i] == '\0')
                break;
        }
        bCount = i;

#ifdef DEBUG_USBUART
        char str[20];
        I2C_CLCD_ClearLine(1u);
        sprintf(str, "%s", UsbRxBuffer);
        I2C_CLCD_Position(1u,0u);
        I2C_CLCD_PrintString(str);
#endif
		for (i = 0; i < bCount; i++)
		{
			rx = UsbRxBuffer [i];
			ComRxCmd [ComRxPtr++] = rx;	// save in command buffer
			if (rx == ';')				// command string terminator
			{
                // PSoC5LP requires ';' for FactorySetup
    			if ((ComRxCmd [0] == '$') && (ComRxCmd [1] == '*'))
    			{
                    ComRxCmd[i] = '\0';     // '@' -> '\0'
                    xSemaphoreTake(xMutex_DDS, portMAX_DELAY);
    				FactorySetup ();
                    xSemaphoreGive(xMutex_DDS);
    				ComRxPtr = 0;
    			}
                else
                {
                    xSemaphoreTake(xMutex_DDS, portMAX_DELAY);
    				ProcessComRx ();
                    xSemaphoreGive(xMutex_DDS);
    				ComRxPtr = 0;
                }
			}
			else
				ComRxPtr &= sizeof(ComRxCmd) - 1;
		}
	}
}

//
//	Factory setup commands
//
void FactorySetup (void)
{
	uint8 sendUsb = FALSE;
    uint8 i;
	
	switch (ComRxCmd [2])
	{
		//case 'b':						// bootloader mode
		//	CyBtldr_Load();				// enter USB boot loader mode
		//	break;
			
		case 'c':						// calibrate frequency mode
			memcpy (LastFreq, "12345678", 8);	// force frequency change
            // AD9850_DDS
    		memcpy (Freq, "05000000", 8);		// set frequency to 5MHz
			FrequencyError = 0;
			SetFrequency ();
			memcpy (UsbTxBuffer, "Calibrate", 9);
			sendUsb = 9;
			break;
			
		case 'd':						// debug mode
			Debug = TRUE;
			memcpy (UsbTxBuffer, "Debug Mode", 10);
			sendUsb = 10;
			break;
			
		case 'n':						// store serial number in eeprom
			CySetTemp ();				// acquire die temperature before writing eeprom
			if (EEPROM_Write (&ComRxCmd [3], SN_ROW) == CYRET_SUCCESS)
				LedTimer = LED_BLINK;	// if successful write, blink the LED
			break;
			
		case 'f':						// store frequency offset in eeprom
			CySetTemp ();				// acquire die temperature before writing eeprom
			if (EEPROM_Write (&ComRxCmd [3], FQ_ROW) == CYRET_SUCCESS)
			{
				LedTimer = LED_BLINK;	// if successful write, blink the LED
				memcpy (LastFreq, "12345678", 8);	// force frequency change
                //AD9850_DDS
				memcpy (Freq, "05000000", 8);		// set frequency to 5MHz
                // PSoC3 => PSoC5LP
                for (i = 0; i < PARAM_MAX; i++)
                    FREQ_ERROR[i] = pFREQ_ERROR[i];
                // AD9850_DDS
				FrequencyError = 5000000 - BinaryFrequency (FREQ_ERROR);	// compute binary value from string
				SetFrequency ();
			}
//			break;

		case '?':						// status command, reply with eeprom data
            // PSoC3 => PSoC5LP
			//memcpy (UsbTxBuffer, SERIAL_NUM, 8);		// serial number
            for (i = 0; i < PARAM_MAX; i++)
                UsbTxBuffer[i] = pSERIAL_NUM[i];
			UsbTxBuffer [8] = ' ';
			//memcpy (&UsbTxBuffer [9], FREQ_ERROR, 8);	// frequency offset at 10MHz
            for (i = 0; i < PARAM_MAX; i++)
                UsbTxBuffer[9 + i] = pFREQ_ERROR[i];
			sendUsb = 17;
			break;
	}

	if (sendUsb)
	{
        // PSoC3 => PSoC5LP
		//USBUART_Write(UsbTxBuffer, sendUsb);	// send response
        UsbTxBuffer[sendUsb] = '\0';
		USBUART_Write(UsbTxBuffer);	// send response
		USBUART_Write((uint8*)"\r\n");	// send response
		while(!USBUART_bTxIsReady()) ;
	}
}



//============================================================================
//
//	Task_RADIO
//
//============================================================================
void Task_RADIO(void *pvParameters)
{
    const portTickType xDelay = 1 / portTICK_RATE_MS;

    // Main Loop
 	while (1)
	{
		AdjustAgc ();				// AGC adjustment		
        
        vTaskDelay(xDelay);
    }
}

//----------------------------------------------------------------------------
//
//	ADC interrupt processing
//
//	Interrupts every 31.18 usec, 32068 sps, 16034 sps per channel
//	TP2 is low for 8.5 to 11 usec (optimization 5), freq = 14.070 MHz = Fvco = 56.28 MHz
//----------------------------------------------------------------------------
// added AM mode (2017.6.24)koseki
#define MLT_A 10    // magnification for CORDIC

CY_ISR(ADC_ISR_Handler)
{
	int16  rxRaw;		// must be signed int
	uint16 sample;		// less compiled code when using unsigned int
	int32  I_chan = 0, Ikn;		// must be signed int
	int32  Q_chan = 0, Qkn;		// must be signed int
    uint8  i;
        
	//CyPins_ClearPin(TP2_OUT_0);

	if (AdcState & 1)			// I channel input processing
	{
		IQMUX_Control = 2;		// selects I channel of IQMUX, IQMUX_Write (2);
		
		// read ADC, subtract out DC offset, and multiply by gain
		rxRaw = ADC_GetResult16 () - IDCOffset;
		IDCOffset += (rxRaw & 0x8000) ? -1 : 1;	// calc new DC offset
		rxRaw = rxRaw * AgcGain;
        IDelay [IDelayPtr++] = rxRaw;			// store I channel in delay line
		IDelayPtr &= 31;
   		// Write Filter A output to PRS DAC
		VDAC_Data = Filter_HOLDAH_REG ^ 0x80;

        // (2017.6.24)koseki
        if (rxRaw < 0)
            rxRaw = -rxRaw;
        I_chan = (int32)rxRaw << MLT_A;
    }
	else						// Q channel input processing
	{
		IQMUX_Control = 1;		// selects Q channel of IQMUX, IQMUX_Write (1);

		// read ADC, subtract out DC offset, and multiply by gain
		rxRaw = ADC_GetResult16 () - QDCOffset;
		QDCOffset += (rxRaw & 0x8000) ? -1 : 1;	// calc new DC offset before any gain adjust
		rxRaw = rxRaw * AgcGain;

        // (2017.6.24)koseki
        if (Mode != MODE_AM)
        {
            if (UpperSideBand)
    			sample = IDelay [IDelayPtr] - Filter_Read16 (Filter_CHANNEL_B);
    		else
    			sample = IDelay [IDelayPtr] + Filter_Read16 (Filter_CHANNEL_B);

            // Filter_Write16 (Filter_CHANNEL_A, IDelay [IDelayPtr] +/- Filter_Read16 (Filter_CHANNEL_B));
    		Filter_STAGEAM_REG = (uint8)(sample);
            Filter_STAGEAH_REG = (uint8)(sample >> 8);

    		//  replace Filter_Write16 (Filter_CHANNEL_B, rxRaw);
            Filter_STAGEBM_REG = (uint8)(rxRaw);
            Filter_STAGEBH_REG = (uint8)(rxRaw >> 8);
        }
        else // Mode == MODE_AM
        {
            if (rxRaw < 0)
                rxRaw = -rxRaw;
            Q_chan = (int32)rxRaw << MLT_A;
            //CORDIC Routine (16 bits)
            for (i = 0; i < 16; i++)
            {
                if (Q_chan >= 0) 
                {
                    Ikn = I_chan + (Q_chan >> i);
                    Qkn = Q_chan - (I_chan >> i);
                }
                else        
                {
                    Ikn = I_chan - (Q_chan >> i);
                    Qkn = Q_chan + (I_chan >> i);
                }
                I_chan = Ikn;
                Q_chan = Qkn;
            }
            // Ikn = 1.6467602 * xqrt(I^2 + Q^2)
            sample = (uint16)(Ikn >> MLT_A);

            // Filter_Write16 (Filter_CHANNEL_A, sample);
            Filter_STAGEAM_REG = (uint8)(sample);
            Filter_STAGEAH_REG = (uint8)(sample >> 8);
        }

        // AdcState == 0 ; 32086 / 256 = 125.33(Hz)= 7.98(ms)
		if (!AdcState)
			AdcTick = TRUE;
    }
	AdcState++;
	
	if (rxRaw > AdcPeak)
		AdcPeak = rxRaw;
	
	//CyPins_SetPin(TP2_OUT_0);		   

}

//
//	Adjust AGC by monitoring ADC peak signal level
//	Adjusts gain every 8 msec, rate of 32068 / 256 Hz
//
void AdjustAgc (void)
{
	uint16 atten;
	
	if (!AdcTick)					// 8 msec tick
		return;
	AdcTick = FALSE;
	
	if (LedTimer)
	{
		if (--LedTimer == 0)
			//CyPins_SetPin (REDLED_0);	// red led off
            LED_Write(0u);
		else
			//CyPins_ClearPin (REDLED_0);	// red led on
            LED_Write(1u);
	}	

	if (AgcDisable)
		AdcPeak = 0;				// disable AGC adjustments and go to max gain
	else if (AdcPeak > 0x3800)
	{
		AgcIntegrator = (AgcIntegrator >> 2) * 3;	// overloaded input, reduce gain to 75%
		AgcGain = 1 + (AgcIntegrator >> 2);	
		LedTimer = LED_SHORTBLINK;	// blink the LED for overload
	}
	AdcPeakAve = (AdcPeakAve + AdcPeak) / 2;		// compute average peak ADC value
	AdcPeak = 0;	
	
	if (--AgcTimer)
		return;
	//AgcTimer = 4;					// every 32 msec
	AgcTimer = AgcTimeConstant;		// controlled by GT command (AgcTimeConstant * 8 ms)
	
	atten = (AttenuatorOn) ? 0x1000 : 0x2800;
	if (AdcPeakAve < atten)			 // clips if higher than this number
	{
		if (AgcIntegrator != 0xFF)
			AgcIntegrator++;		// increase gain
	}
	else if (AgcIntegrator)
		AgcIntegrator--;			// decrease gain
		
	AgcGain = 1 + (AgcIntegrator >> 2);

}


// [] END OF FILE
